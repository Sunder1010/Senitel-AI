# SENTINEL AI

## AI Video Safety & Operations Monitoring Platform

SENTINEL converts CCTV and video streams into actionable, explainable safety and operational events.

### Core Pipeline

Video / CCTV / RTSP
        ↓
OpenCV
        ↓
YOLO Detection
        ↓
ByteTrack Tracking
        ↓
Temporal & Spatial Event Engine
        ↓
Incident Detection
        ↓
Evidence + SQLite

### Current Events

- Restricted-area intrusion
- Crowd detection
- Loitering
- Wrong-direction movement
- Unattended-object detection (planned refinement)

### Technology

- Python
- OpenCV
- Ultralytics YOLO
- ByteTrack
- SQLite
- FFmpeg

### Input Sources

SENTINEL is designed to process:

- Recorded MP4 videos
- Webcam
- RTSP CCTV/IP cameras

### Privacy

SENTINEL is designed around event detection rather than identity recognition.

The system does not require face recognition or identity profiling.

### Project Status

Prototype → Real-world CCTV deployment

The first real-world deployment target is an authorized educational-campus CCTV environment.
